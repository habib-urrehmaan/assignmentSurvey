<!--link github="https://github.com/habiburrehman012/surveyMaker"-->
<?php
session_start();
if(!isset($_SESSION["email"]) && !isset($_SESSION["email"]))
      {
        header('Location: index.html');
      }
?>

<!DOCTYPE html>
<html>
<head>
	<style>
	#formName
	{
		color:red;
	}
	body
	{
		background-color: grey;
	}
	</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function() {
	 var formnam;
	 var count=0;
   var rcount=0;
   var ccount=0;
    $("#add").click(function() {
    	    
    if (formnam == undefined) {
    	formnam=prompt("enter form name", " ");
        $("#formName").html(formnam) ;
    }
          var fieldtype=prompt("enter field type(text/submit/password/radio/checkbox/button)","text");
          var label=prompt("enter field label/value(in case of submit/button)","label");
          count=count+1;
    if (fieldtype != null && label!=null) {
    	if(fieldtype=="text"||fieldtype=="password")
         $("#dynamicform").append(label+":<input type='"+fieldtype+"'"+" "+"id='field"+count+"'"+" name=id['"+count +"]'/><br/><br/>");
     	if(fieldtype=="submit"||fieldtype=="button")
     		$("#dynamicform").append("<input type='"+fieldtype+"'"+" "+"value='"+label+"'"+" "+"id='field"+count+"'"+" name='id["+count +"]' /><br/><br/>");
     	if(fieldtype=="checkbox"||fieldtype=="radio")//Run this in case of check box or radio
     		{
          var num=prompt("enter number of radio buttons to place","1");
          
          rcount=rcount+1;
          //run this when radio is selected
          if(fieldtype=="radio")
          {
            $("#dynamicform").append("<label>"+label+":</label><br>");
            for (i = 0; i < num; i++) 
            {
              var slabel=prompt("enter sub categories","sub category");
             $("#dynamicform").append("<label>"+slabel+"</label><input type='"+fieldtype+"'"+" "+"value='"+slabel+"'"+" "+"id='field"+rcount+"' /><br/>");
            }
          }
          //run this when checkbox is selected
          if(fieldtype=="checkbox")
          {
            $("#dynamicform").append("<label>"+label+":</label><br>");
            for (i = 0; i < num; i++) 
            {
              var slabel=prompt("enter sub categories","sub category");
            $("#dynamicform").append("<label>"+slabel+":</label><input type='"+fieldtype+"'"+" "+"value='"+slabel+"'"+" "+"id='field"+rcount+"' /><br/>");
            }
          }
        }
        $("#dynamicform").append("<br>");
      //if(fieldtype=="checkbox")
    }
        	
        	
        	
        	//$("#dynamicform").append(label+":<input id='field"+x+"' "+"type='"+fieldtype+ "' ></input><br/>");
       
    });
$("input:checkbox").on('click', function() {
  // in the handler, 'this' refers to the box clicked on
  var $box = $(this);
  if ($box.is(":checked")) {
    // the name of the box is retrieved using the .attr() method
    // as it is assumed and expected to be immutable
    var group = "input:checkbox[name='" + $box.attr("name") + "']";
    // the checked state of the group/box on the other hand will change
    // and the current value is retrieved using .prop() method
    $(group).prop("checked", false);
    $box.prop("checked", true);
  } else {
    $box.prop("checked", false);
  }
});
});

</script>
</head>
<body>
  <nav><a href="home.php">Home</a></nav>
<h2 id="formName"></h2>
<form id="dynamicform" method="POST">

</form>
<input type='button' value="addfield" class="add" id="add" />
<br>
<input type='button' value="finish" class="finish" id="finish" onclick="window.location.replace('survey.php')"/>
<div>
  <h3>Visibility:</h3>
  <label>
    <input type="checkbox" class="radio" value="1" id="radio1" name="fooby[1][]" />Private</label>
  <label>
    <input type="checkbox" class="radio" value="1" id="radio2" name="fooby[1][]" />Public</label>
</div>

</body>
</html>