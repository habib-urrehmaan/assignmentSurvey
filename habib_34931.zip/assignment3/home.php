<?php
session_start();
if(!isset($_SESSION["email"]) && !isset($_SESSION["email"]))
      {
        header('Location: index.html');
      }
?>

<html>
<body>

<a href="logout.php" style="margin-left:1200">Logout</a>
<?php
$parts=explode('@',$_SESSION['email']);
$uname=$parts['0'];
echo "<h1>Welcome ".$uname." to your Dashboard</h1>";
?>

<a href='form_generate.php'>MAKE SURVEY FORM</a><br>
<a href='private_survey'>FiLL PRIVATE SURVEYS</a>
</body>
</html>