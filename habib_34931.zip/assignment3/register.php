
<?php
//echo "<h2>Register</h2>";


if (isset($_POST['email']) && !empty($_POST['email'] && isset($_POST['pass']) && !empty($_POST['pass'])))
{

$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "survey";
	$con = mysqli_connect($servername,$username,$password,$dbname); //connect to database
	$email=$_POST['email'];
	$pass=$_POST['pass'];

	if (mysqli_connect_errno())
  	{
  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
  	}

  	else
  	{
  		/*$sql = "SELECT email FROM authentication";
		$result = $con->query($sql);

  		while($row = $result->fetch_assoc()) 
    	{
    			//check whether email entered is valid or invalid
        		if($_POST['email']==$row['email'])
        		{
        			echo "error email already exists add other and <a href='Index.html'>try again</a>";
        			break;
				}
    			else
    			{*/
  					//Apply query to get email and password that are stored in database
  					$sql = "insert into authentication(email,password) values ('$email','$pass')";
  					$result = $con->query($sql);

					if ($result) //if query works
					{
    					echo "<p style='color:green'>you have been registered Successfully!</p>";
    					echo "Goto <a href='index.html'>Home</a> Page";
			
						$con->close();	
					}
					else
						echo "Server Error!";
					//continue;
				//}
		}
}

else
echo "<p style='color:red'>Please Fill in the fields</p>";
?>